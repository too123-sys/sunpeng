package com.shanzhu.market.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.shanzhu.market.entity.domain.DetailSaleRecords;

public interface IDetailSaleRecordsService extends IService<DetailSaleRecords> {
}
