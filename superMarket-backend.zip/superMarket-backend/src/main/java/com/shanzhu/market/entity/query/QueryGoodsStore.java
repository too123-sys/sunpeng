package com.shanzhu.market.entity.query;

public class QueryGoodsStore  extends BaseQuery {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
